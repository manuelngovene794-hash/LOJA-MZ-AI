"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase-browser";

type Store = { id:string; name:string; slug:string; subscription_status:string; plan:string };
export default function Dashboard() {
  const [store,setStore] = useState<Store|null>(null);
  const [loading,setLoading] = useState(true);
  const [error,setError] = useState("");
  const router = useRouter();
  useEffect(()=>{ (async()=>{
    try {
      const supabase=createClient();
      const {data:{user}}=await supabase.auth.getUser();
      if(!user){router.replace("/entrar");return;}
      const {data,error}=await supabase.from("stores").select("id,name,slug,subscription_status,plan").eq("owner_id",user.id).maybeSingle();
      if(error) throw error;
      setStore(data);
    } catch(e){setError(e instanceof Error?e.message:"Erro ao carregar a loja.");}
    finally{setLoading(false);}
  })(); },[router]);
  async function logout(){const supabase=createClient();await supabase.auth.signOut();router.replace("/entrar");}
  if(loading)return <main className="container" style={{padding:40}}>A carregar a tua área...</main>;
  return <main className="container" style={{padding:"30px 0"}}>
    <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12}}><div className="brand">LOJA MZ AI</div><button className="btn btn-light" onClick={logout}>Terminar sessão</button></header>
    <h1 style={{marginTop:35}}>Painel da loja</h1>
    {error&&<p style={{color:"#c71920"}}>{error}</p>}
    {!store?<section className="panel"><h2>A tua loja ainda está a ser preparada</h2><p className="muted">A conta foi autenticada. O registo da loja será criado pela rotina segura de provisionamento no Supabase.</p></section>:
    <section className="panel"><h2>{store.name}</h2><p>Endereço público: <a style={{color:"#c71920"}} href={`/loja/${store.slug}`}>{`/loja/${store.slug}`}</a></p><p>Plano: {store.plan}</p><p>Estado: {store.subscription_status==="active"?"Ativa": "A aguardar ativação do pagamento"}</p></section>}
    <p className="muted" style={{marginTop:18}}>O painel de produtos, encomendas, finanças, clientes e assistente IA será ligado às tabelas e permissões de produção antes da publicação final.</p>
  </main>;
}
