"use client";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase-browser";

export default function RegisterPage() {
  const [store,setStore] = useState("");
  const [phone,setPhone] = useState("");
  const [password,setPassword] = useState("");
  const [plan,setPlan] = useState("basic");
  const [show,setShow] = useState(false);
  const [error,setError] = useState("");
  const [busy,setBusy] = useState(false);
  const router = useRouter();
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      const supabase = createClient();
      const { data, error } = await supabase.auth.signUp({
        phone: phone.trim(), password,
        options: { data: { store_name: store.trim(), requested_plan: plan } }
      });
      if (error) throw error;
      if (data.session) { router.push("/painel"); router.refresh(); }
      else setError("Conta criada. Se o Supabase solicitar confirmação por telefone, termina essa confirmação para poderes entrar. Não é necessária confirmação por Gmail.");
    } catch (err) { setError(err instanceof Error ? err.message : "Não foi possível criar a conta."); }
    finally { setBusy(false); }
  }
  return <main className="container" style={{maxWidth:520,padding:"42px 0"}}>
    <Link className="brand" href="/">LOJA MZ AI</Link>
    <section className="panel" style={{marginTop:22}}>
      <h1>Criar a tua loja</h1><p className="muted">Preenche os dados para registar uma loja real.</p>
      <form onSubmit={submit} style={{display:"grid",gap:13,marginTop:20}}>
        <label>Nome da loja<input className="field" value={store} onChange={e=>setStore(e.target.value)} required minLength={2} placeholder="Ex.: Loja da Maria"/></label>
        <label>Número de telefone<input className="field" value={phone} onChange={e=>setPhone(e.target.value)} required placeholder="+258 8XXXXXXXX"/></label>
        <label>Senha<div style={{display:"flex",gap:8}}><input className="field" type={show?"text":"password"} value={password} onChange={e=>setPassword(e.target.value)} required minLength={8} placeholder="Mínimo 8 caracteres"/><button type="button" className="btn btn-light" onClick={()=>setShow(!show)}>{show?"Esconder":"Mostrar"}</button></div></label>
        <label>Plano<select className="field" value={plan} onChange={e=>setPlan(e.target.value)}><option value="basic">Básico — 200 MT/mês — 50 produtos</option><option value="pro">Profissional — 500 MT/mês — 200 produtos</option><option value="business">Empresarial — 1.000 MT/mês — 1.000 produtos</option></select></label>
        {error && <p style={{color:"#c71920",lineHeight:1.5}}>{error}</p>}
        <button className="btn btn-red" disabled={busy}>{busy?"A criar conta...":"Criar conta"}</button>
      </form>
      <p className="muted">Já tens conta? <Link href="/entrar" style={{color:"#c71920",fontWeight:700}}>Entrar</Link></p>
    </section>
  </main>;
}
