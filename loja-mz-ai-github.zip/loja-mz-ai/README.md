# LOJA MZ AI

Projeto inicial independente para a plataforma moçambicana de gestão de lojas.

## Tecnologias
- Next.js 15 / React 19
- Supabase Auth, PostgreSQL, Row Level Security e Storage
- PWA manifest inicial

## Ficheiros
- `app/`: páginas inicial, registo, login, painel e montra pública.
- `lib/supabase-browser.ts`: cliente Supabase no navegador.
- `supabase/schema.sql`: tabelas, políticas RLS, bucket de imagens e criação automática de perfil/loja após registo.
- `.env.example`: variáveis necessárias.

## Preparação para GitHub
1. Criar um repositório novo chamado `loja-mz-ai`.
2. Enviar o conteúdo desta pasta para a raiz do repositório (não enviar a pasta exterior `loja-mz-ai-review`).
3. Criar um projeto Supabase.
4. No Supabase, abrir **SQL Editor**, colar e executar `supabase/schema.sql`.
5. Em **Authentication > Providers**, ativar Phone e configurar um fornecedor SMS válido, ou configurar confirmação de telefone conforme o método de autenticação que pretendes usar.
6. Na Vercel, importar o repositório e definir:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
7. Fazer o deploy.

## Estado e limitações — ler antes de vender
Esta versão é uma base inicial para continuar o desenvolvimento, não uma plataforma comercial completa.

Já inclui:
- Página pública de apresentação e planos (200, 500 e 1.000 MT/mês).
- Registo e login por telefone/senha (dependem da configuração do Supabase Phone Auth e SMS).
- Criação automática de perfil e loja no trigger SQL após a criação da conta.
- Estrutura de painel e montra pública para lojas ativas.
- Tabelas e políticas RLS para produtos, clientes, encomendas, despesas, pagamentos, avaliações e notificações.
- Bucket público de imagens com regras de escrita por proprietário.

Ainda falta implementar e testar:
- Interface completa para criar/editar/apagar produtos e carregar imagens.
- Gestão operacional de clientes e encomendas, incluindo checkout e processamento de pedidos.
- Relatórios financeiros e controlo de stock.
- Integração real com Gemini e Groq (não existe ainda código de chat nem endpoints).
- Painel administrativo e aprovação segura de pagamentos.
- Integração de pagamentos (M-Pesa/e-Mola ou outro fornecedor).
- Recuperação de senha e fluxos de confirmação de telefone.
- Testes de ponta a ponta, limites dos planos no servidor, monitorização e hardening de produção.

Não há botão ou modo Demo nesta versão. Não inserir dados fictícios para simular vendas.
Não aceitar pagamentos de clientes nem anunciar a plataforma como pronta enquanto os itens em falta não forem implementados e testados.

## Segurança
- Nunca colocar `SUPABASE_SERVICE_ROLE_KEY`, `GEMINI_API_KEY` ou `GROQ_API_KEY` no código do navegador.
- As variáveis secretas devem ficar apenas no ambiente de servidor.
- Não existe política RLS de atualização direta de perfil/loja pelo cliente: assim, o utilizador não pode promover-se a admin nem ativar a própria subscrição alterando a tabela.
- A aprovação de pagamentos e a ativação de subscrições devem ser feitas por lógica confiável no servidor, nunca pelo cliente.
- O papel `admin` deve ser atribuído manualmente e com cuidado.
